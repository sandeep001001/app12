To Run the application first install the dependancyies using below command

# npm install

Then run the app by using

# npm run

Newsapi Key :

#f5010aa1fefe47258db55540100af60c